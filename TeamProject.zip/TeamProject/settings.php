<?php 
include("includes/header.php");

?>
<!--ADD BOOTSTRAP FOR BETTER STYLING AND LAYOUT-->
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" href="css/adminstyles.css">

<style>
	.wrapper {
		margin-left: 0px;
		padding-left: 0px;
	}

</style>

<!--INCLUDE SIDEBAR-->
<?php include("includes/sidebar.php");?>
<div class="index_main_column column" >

	<?php echo "<h2>"."User Settings"."</h2>"."<hr>";?>

</div>

<footer><?php include("includes/footer.php");?></footer>