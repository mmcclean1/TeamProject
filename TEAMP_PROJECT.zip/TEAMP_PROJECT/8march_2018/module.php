<?php 
include("includes/header.php");

?>

<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" href="css/adminstyles.css">
<style>

	.wrapper {
		margin-left: 0px;
		padding-left: 0px;
	}

	</style>

/*
<!--Matthew McClean - L00137316-->
<!--LYIT Team Project 2018-->
<!--BSc 5-->
*/


<script type="text/javascript" src="assets/js/newTopic.js"></script>


<!--INCLUDE SIDEBAR-->
<?php include("includes/sidebar.php");?>


<!--MAIN CONTENT COLUMN-->
<div class="index_main_column column" >

	<a id="back" href="index.php"><i class="far fa-arrow-alt-circle-left fa-2x" style="color:blue"></i></a>
	<?php
	//Get passed in ModuleNo
	$moduleNo=$_GET['ModuleNo'];

	//Connect to database
	$connection = mysqli_connect("localhost:3307","root","");
	mysqli_select_db($connection,"studentsupport");

	//Get Module Name
	$moduleResult=mysqli_query($connection,"SELECT ModuleName FROM module WHERE ModuleNo='$moduleNo'");
	while($row=mysqli_fetch_array($moduleResult))
	{print("<title>".$row['ModuleName']."</title><h1>".$row['ModuleName']."</h1>");}


	//Create new topic
	print("<button id='newTopic'>Add New Topic</button>");
	print("<br>"."<br>"."<br>");
	print("<div id='div' style=display:none><form method=POST action=topicHandler.php?ModNo=".$moduleNo.">Enter Title:<input id=title name=title type=text /><input id=submit type=submit value=Submit></form></div>");

	?>
	
	<div id ="modulesDiv">
		<div class="col-md-8 col-md-offset-2">
			<table class="table table-striped">
				<thead>
					<tr class="bg-success">
						<th>ModulesNo</th>
						<th>Topic</th>
					</tr>
				</thead>
				<tbody>
					<?php

					//Get topics associated with module
					$result=mysqli_query($connection,"SELECT * FROM topic WHERE ModuleNo='$moduleNo'");
					while($row=mysqli_fetch_array($result))
					{
						print("<tr><td>".$row['TopicNo']."</td>");
						print("<td><a href=topic.php?TopicNo=".$row['TopicNo'].">".$row['TopicName']."</a></td></tr>");
					}
					//Close connection
					mysqli_close($connection);
					?>
				</tbody>
			</table>
		</div>
	</div>

	<footer><?php include("includes/footer.php");?></footer>
	</body>
</html>