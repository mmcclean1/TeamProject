<?php
echo "<p>Copyright &copy; " . date("Y") . " Logos.com</p>";

?>