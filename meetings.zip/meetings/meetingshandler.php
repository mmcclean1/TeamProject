<?php
//Declaring variables to prevent errors
$mId = ""; //
$room = ""; //room
$details = ""; //details
$date = ""; //date 


if(isset($_POST['book_button'])){
	
	//Details
	$Details = strip_tags($_POST['Details']); //Remove html tags
	$ Details= str_replace(' ', '', $Details); //remove spaces
	$Details = ucfirst(strtolower($Details)); //Uppercase first letter
	$_SESSION['Details'] = $Details; //Stores first name into session variable
	