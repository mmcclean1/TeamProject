
<?php
print '<h1>';
print(date("Y"));
print '</h1>';
print '<hr>';
  $connection = mysqli_connect("localhost","root","");
  mysqli_select_db($connection,"studentsupport");
  $meetings=mysqli_query($connection,"select * from meetings");
  print("<table border=1>");
  print '<th>'."Meetings".'</th>;
  while($row=mysqli_fetch_array($meetings))
  {
		print '<tr>';
		print '<td>'. $meeting['MeetingNo'].'</td>';
	
  }
  
  mysqli_close($connection);
?>

</body>

</html>