<?php
 
$connection = mysqli_connect("localhost","root","");
  mysqli_select_db($connection,"studentsupport");
  
  
?>

<html>
<head>
<h1>Meetings</h1>
</head>
<body>
<table width="400" border="2" align="center" >
<tr>
<form id="forum3" name="forum3" method="post" action=".php">
<td>
<table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
<tr>
<td colspan="3" ><strong>Create Meeting</strong> </td>
</tr>
<tr>
<td><strong>Name</strong></td>
<td>:</td>
<td><input name="name" type="text"placeholder="Full Name" id="topic" size="50" /></td>
</tr>
<tr>
<td><strong>Email</strong></td>
<td>:</td>
<td><input name="email" type="text"placeholder="Email" id="email" size="50" /></td>
</tr>
<tr> 
<td valign="top"><strong>Detail</strong></td>
<td valign="top">:</td>
<td><textarea name="detail" cols="50" rows="5" id="detail"></textarea></td>
</tr>
<tr>
<td><label for="time" class="label-date"><i class="fa fa-calendar"></i>&nbsp;&nbsp;Date:</label></td>
        <td><input type="date" id="time" class="floatLabel" name="time" value="<?php echo date('Y-m-d'); ?>"></td>
        </tr>
       
      
     <tr>
      <label for="Room">Room:</label>
      <i class="fa fa-sort"></i>
      <select class="floatLabel">
        <option value="room"></option>
        <option value="room" selected>With 3 people</option>
        <option value="room" selected>With 4 people</option>
        <option value="room" selected>With 5 people</option>
        <option value="room" selected>With 6 people</option>
        <option value="room" selected>With 8 people</option>
      </select>
     </tr> 
      </div> 
      <td><button type="submit" value="Submit" align="right" class="col-1-4">Book Room</button></td>
      
    </div>
    

</table>
</td>
</form>


</tr>
</table>
</body>
</html>

