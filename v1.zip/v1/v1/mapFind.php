<?php 
include("includes/header.php");

?>


<style>
	.wrapper {
		margin-left: 0px;
		padding-left: 0px;
	}

</style>

<!--COULD CHANGE THE NAME OF THIS CLASS TO SIDE BAR-->
<div class="sidbar_left">


</div>

<!DOCTYPE html>
<html lang="en">
	<head>

		<meta charset="UTF-8">
		
		<!--SPECIFY CORRECT FOLDER-->
<!--	<script src="assets/js/weather.js"></script>-->

		<!--COPY AND PASTE FROM GOOGLE STEP TWO AND INSERT THE KEY THIS WILL ALLOW YOU TO RUN ON LOCALHOST-->
<!--
		<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB2daH7B0_0N2blOjsRU7z2w4UQpCdkMQA&callback=initMap"
				  type="text/javascript"></script>
-->

		<title>Map Finder</title>

		<style>

			table, td {
				border: 1px solid black;
			}
		</style>

	</head>

	<body>
	

		<div class="index_main_column column" >
		
			<?php echo "<h2>"."Find You Way"."</h2>"."<hr>";?>
			
			Destination: <input type="text" id="destination" /><br /><br/>
			<button id="btnPath" onclick="findPath();">Show Path</button><hr>
			<div id="mapArea" style="width:600px;height:400px;"></div>
			

		</div>


	</body>

</html>