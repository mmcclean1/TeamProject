<?php 
include("includes/header.php");


?>

<style>
	.wrapper {
		margin-left: 0px;
		padding-left: 0px;
	}

</style>

<!--COULD CHANGE THE NAME OF THIS CLASS TO SIDE BAR-->
<div class="sidbar_left">


</div>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Meetings</title>
	</head>
	<body>

		<div class="index_main_column column" >

			<?php echo "<h2>"."Schedule Meetings"."</h2>"."<hr>";?>


		</div>

	</body>
</html>


