<?php 
include("includes/header.php");

?>


<style>
	.wrapper {
		margin-left: 0px;
		padding-left: 0px;
	}

</style>

<!--COULD CHANGE THE NAME OF THIS CLASS TO SIDE BAR-->
<div class="sidbar_left">


</div>


<div class="index_main_column column" >

	<?php echo "<h2>"."User Settings"."</h2>"."<hr>";?>


</div>