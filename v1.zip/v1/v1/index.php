
<?php 
include("includes/header.php");

//if(isset($_POST['post'])){
//	$post = new Post($con, $userLoggedIn);
//	$post->submitPost($_POST['post_text'], 'none');
//}

 ?>
 
<!-- !--STYLES THE PROFILE BAR-->
<style>
	.wrapper {
		margin-left: 0px;
		padding-left: 0px;
	}

</style>


<!--COULD CHANGE THE NAME OF THIS CLASS TO SIDE BAR-->
<div class="sidbar_left">


</div>


<!--MAIN CONTENT COLUMN-->
<div class="index_main_column column" >
<!--<h2><?php echo "Topics"; ?></h2>-->

	<?php

		//PRINT HEADING
		print "<h2>"."Select Module"."</h2>"."<hr>";
		
		?>
		<!--CREATE HTML FORMS ONE FOR YEARS -->
			<b>Year:</b>	
			<select id='year'>
				<option>All</option>

				<?php
				
				
				//RUN QUERY 
				$result = mysqli_query($con,"SELECT ModuleNo from module");
				while($row = mysqli_fetch_array($result))   {

					echo "<option value=".$row["ModuleNo"].">".$row["year"]."</option>";

				}

				?>

			</select>

			<!--CREATE HTML FORM-->
			<b>Module:</b>	
			<select id="name">
				<option>All</option>

				<?php
				
				//RUN QUERY 
				$result = mysqli_query($con,"SELECT ModuleNo,ModuleName from module");
				while($row = mysqli_fetch_array($result))   {

					echo "<option value=".$row["ModuleNo"].">".$row["ModuleName"]."</option>";

				}
				
				?>

			</select>
			
			<!--FIND BUTTON-->
			<button id="btn">Find</button>

		<hr>
		<!--PUT POPLATE TABLE HERE-->
		<div id="myTable"></div>

</body>
</html>