
<?php

//INCLUDES THE BADWORD FILTER FUNCTION CAN BE CALLED IN OTHER CLASSES
include_once("badwords.php");

$myData = "Hi douche, damn I want to punch you for a good cause!";
$cleaned = badWordFilter($myData);

echo $cleaned;

?>