-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jan 29, 2018 at 05:36 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `social`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_body` text NOT NULL,
  `posted_by` varchar(60) NOT NULL,
  `posted_to` varchar(60) NOT NULL,
  `date_added` datetime NOT NULL,
  `removed` varchar(3) NOT NULL,
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_body`, `posted_by`, `posted_to`, `date_added`, `removed`, `post_id`) VALUES
(1, 'wonderful!!!', 'bart_simpson', 'lisa_simpson', '2017-08-30 17:17:18', 'no', 20),
(2, 'thank you.', 'bart_simpson', 'minnie_mouse', '2017-08-30 17:20:12', 'no', 18),
(3, 'sure no problem', 'rachel_rush', 'rachel_rush', '2018-01-26 15:47:28', 'no', 28),
(4, 'hi bart', 'john_lee_1', 'john_lee_1', '2018-01-26 16:43:10', 'no', 36),
(5, 'you done that assignment?', 'john_lee_1', 'john_lee_1', '2018-01-26 16:43:21', 'no', 36),
(6, 'no assignments this week!', 'lisa_simpson', 'lisa_simpson', '2018-01-26 21:54:26', 'no', 66),
(7, 'wake up', 'bart_simpson', 'bart_simpson', '2018-01-28 23:16:57', 'no', 107),
(8, 'excellent well done!!', 'bart_simpson', 'lisa_simpson', '2018-01-28 23:18:34', 'no', 66),
(9, 'great well done!!', 'bart_simpson', 'bart_simpson', '2018-01-28 23:21:09', 'no', 107),
(10, 'lets do i!!', 'bart_simpson', 'lisa_simpson', '2018-01-28 23:21:23', 'no', 66),
(11, 'hi everyone', 'john_lee', 'bart_simpson', '2018-01-28 23:52:29', 'no', 109),
(12, '', 'john_lee', 'bart_simpson', '2018-01-28 23:56:52', 'no', 109),
(13, 'great beer home!!', 'john_lee', 'john_lee', '2018-01-29 01:44:29', 'no', 115);

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `username` varchar(60) NOT NULL,
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `username`, `post_id`) VALUES
(3, 'bart_simpson', 20),
(4, 'bart_simpson', 19),
(5, 'rachel_rush', 6),
(9, 'john_lee_1', 36),
(17, 'john_lee', 70),
(24, 'john_lee', 115);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `body` text NOT NULL,
  `added_by` varchar(60) NOT NULL,
  `user_to` varchar(60) NOT NULL,
  `date_added` datetime NOT NULL,
  `user_closed` varchar(3) NOT NULL,
  `deleted` varchar(3) NOT NULL,
  `likes` int(11) NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `body`, `added_by`, `user_to`, `date_added`, `user_closed`, `deleted`, `likes`, `image`) VALUES
(64, 'hi everyone', 'john_lee', 'none', '2018-01-26 20:56:50', 'no', 'no', 0, ''),
(65, 'bart here all good', 'bart_simpson', 'none', '2018-01-26 20:58:17', 'no', 'no', 0, ''),
(66, 'any assignments this week folks?', 'lisa_simpson', 'none', '2018-01-26 20:59:50', 'no', 'no', 0, ''),
(70, 'homer', 'john_lee', 'none', '2018-01-26 23:18:21', 'no', 'yes', 1, 'imageName'),
(73, 'how do i upload a picture', 'lisa_simpson', 'none', '2018-01-28 21:15:13', 'no', 'yes', 0, 'imageName'),
(74, 'like this', 'lisa_simpson', 'none', '2018-01-28 21:15:34', 'no', 'yes', 0, 'imageName'),
(75, 'hi', 'lisa_simpson', 'none', '2018-01-28 21:48:55', 'no', 'yes', 0, 'assets/images/posts/5a6e4547b144dhomer.jpg'),
(76, 'hi', 'lisa_simpson', 'none', '2018-01-28 21:49:32', 'no', 'yes', 0, 'assets/images/posts/5a6e456ce2030homer.jpg'),
(77, 'hi', 'lisa_simpson', 'none', '2018-01-28 21:51:31', 'no', 'yes', 0, 'assets/images/posts/5a6e45e31a2fchomer.jpg'),
(78, 'hi', 'lisa_simpson', 'none', '2018-01-28 21:51:44', 'no', 'yes', 0, 'assets/images/posts/5a6e45f04cb8chomer.jpg'),
(79, 'hi', 'lisa_simpson', 'none', '2018-01-28 21:51:50', 'no', 'yes', 0, 'assets/images/posts/5a6e45f60a178homer.jpg'),
(80, 'hi', 'lisa_simpson', 'none', '2018-01-28 21:51:55', 'no', 'yes', 0, 'assets/images/posts/5a6e45fbcfad0homer.jpg'),
(81, 'hi', 'lisa_simpson', 'none', '2018-01-28 21:52:02', 'no', 'yes', 0, 'assets/images/posts/5a6e460232e43homer.jpg'),
(82, 'hi', 'lisa_simpson', 'none', '2018-01-28 21:52:09', 'no', 'yes', 0, 'assets/images/posts/5a6e460986a8dhomer.jpg'),
(83, 'hi', 'lisa_simpson', 'none', '2018-01-28 21:52:13', 'no', 'yes', 0, 'assets/images/posts/5a6e460d8552bhomer.jpg'),
(84, 'hi', 'lisa_simpson', 'none', '2018-01-28 21:52:17', 'no', 'yes', 0, 'assets/images/posts/5a6e46110093ehomer.jpg'),
(85, 'hi', 'lisa_simpson', 'none', '2018-01-28 21:52:20', 'no', 'yes', 0, 'assets/images/posts/5a6e461409d90homer.jpg'),
(86, 'hi', 'lisa_simpson', 'none', '2018-01-28 21:52:26', 'no', 'yes', 0, 'assets/images/posts/5a6e461a30f5dhomer.jpg'),
(87, 'hi', 'lisa_simpson', 'none', '2018-01-28 21:52:32', 'no', 'yes', 0, 'assets/images/posts/5a6e46203d292homer.jpg'),
(88, 'hi', 'lisa_simpson', 'none', '2018-01-28 21:52:39', 'no', 'yes', 0, 'assets/images/posts/5a6e4627eb26ahomer.jpg'),
(89, 'HI', 'lisa_simpson', 'none', '2018-01-28 22:06:04', 'no', 'yes', 0, 'assets/images/posts/5a6e494c10284homer.jpg'),
(90, 'great', 'lisa_simpson', 'none', '2018-01-28 22:22:49', 'no', 'yes', 0, 'imageName'),
(91, 'homer', 'lisa_simpson', 'none', '2018-01-28 22:23:05', 'no', 'yes', 0, 'imageName'),
(92, 'homer', 'lisa_simpson', 'none', '2018-01-28 22:25:06', 'no', 'yes', 0, 'imageName'),
(93, 'homer', 'lisa_simpson', 'none', '2018-01-28 22:25:30', 'no', 'yes', 0, 'imageName'),
(94, 'homer', 'lisa_simpson', 'none', '2018-01-28 22:26:17', 'no', 'yes', 0, 'imageName'),
(95, 'homer', 'lisa_simpson', 'none', '2018-01-28 22:26:21', 'no', 'yes', 0, 'imageName'),
(96, 'homer', 'lisa_simpson', 'none', '2018-01-28 22:28:46', 'no', 'yes', 0, 'imageName'),
(97, 'homer', 'lisa_simpson', 'none', '2018-01-28 22:29:22', 'no', 'yes', 0, 'imageName'),
(98, 'homer', 'lisa_simpson', 'none', '2018-01-28 22:37:35', 'no', 'yes', 0, 'imageName'),
(99, 'homer', 'lisa_simpson', 'none', '2018-01-28 22:37:56', 'no', 'yes', 0, 'imageName'),
(100, 'homer', 'lisa_simpson', 'none', '2018-01-28 22:39:06', 'no', 'yes', 0, 'imageName'),
(101, 'homer', 'lisa_simpson', 'none', '2018-01-28 22:43:59', 'no', 'yes', 0, 'imageName'),
(102, 'homer', 'lisa_simpson', 'none', '2018-01-28 22:44:03', 'no', 'yes', 0, 'imageName'),
(103, 'homer', 'lisa_simpson', 'none', '2018-01-28 22:44:05', 'no', 'yes', 0, 'imageName'),
(104, 'homer', 'lisa_simpson', 'none', '2018-01-28 22:44:08', 'no', 'yes', 0, 'imageName'),
(105, 'homer', 'lisa_simpson', 'none', '2018-01-28 22:44:13', 'no', 'yes', 0, 'imageName'),
(106, 'homer', 'lisa_simpson', 'none', '2018-01-28 22:44:16', 'no', 'yes', 0, 'imageName'),
(107, 'HELLO EVERYONE!!', 'bart_simpson', 'none', '2018-01-28 22:50:18', 'no', 'no', 0, 'imageName'),
(108, 'great pic!!', 'bart_simpson', 'none', '2018-01-28 23:39:41', 'no', 'yes', 0, 'imageName'),
(109, 'great pic!!', 'bart_simpson', 'none', '2018-01-28 23:39:47', 'no', 'no', 0, 'imageName'),
(110, 'hello', 'john_lee', 'none', '2018-01-29 00:23:11', 'no', 'yes', 0, 'imageName'),
(111, 'hello', 'john_lee', 'none', '2018-01-29 00:25:00', 'no', 'no', 0, 'imageName'),
(112, 'hello', 'john_lee', 'none', '2018-01-29 00:27:38', 'no', 'no', 0, 'imageName'),
(113, 'homer', 'john_lee', 'none', '2018-01-29 01:38:06', 'no', 'yes', 0, 'assets/images/posts/5a6e7afe3043chomer.jpg'),
(114, 'homer', 'john_lee', 'none', '2018-01-29 01:39:54', 'no', 'yes', 0, 'assets/images/posts/5a6e7b6a368a2homer.jpg'),
(115, 'homer', 'john_lee', 'none', '2018-01-29 01:40:03', 'no', 'no', 1, 'assets/images/posts/5a6e7b73578a1homer.jpg'),
(116, 'homer', 'john_lee', 'none', '2018-01-29 01:40:08', 'no', 'yes', 0, 'assets/images/posts/5a6e7b78bd6dahomer.jpg'),
(117, 'homer', 'john_lee', 'none', '2018-01-29 01:40:16', 'no', 'yes', 0, 'assets/images/posts/5a6e7b803d4c3homer.jpg'),
(118, 'homer', 'john_lee', 'none', '2018-01-29 01:40:19', 'no', 'yes', 0, 'assets/images/posts/5a6e7b832cadahomer.jpg'),
(119, 'homer', 'john_lee', 'none', '2018-01-29 01:40:22', 'no', 'yes', 0, 'assets/images/posts/5a6e7b86c83b8homer.jpg'),
(120, 'homer', 'john_lee', 'none', '2018-01-29 01:41:01', 'no', 'yes', 0, 'assets/images/posts/5a6e7bade5ec6homer.jpg'),
(121, 'homer', 'john_lee', 'none', '2018-01-29 01:41:44', 'no', 'yes', 0, 'assets/images/posts/5a6e7bd820829homer.jpg'),
(122, 'homer', 'john_lee', 'none', '2018-01-29 01:43:10', 'no', 'yes', 0, 'assets/images/posts/5a6e7c2e77d6fhomer.jpg'),
(123, 'great', 'john_lee', 'none', '2018-01-29 01:58:12', 'no', 'no', 0, 'imageName'),
(124, 'great', 'john_lee', 'none', '2018-01-29 02:00:00', 'no', 'no', 0, 'imageName'),
(125, 'hello', 'john_lee', 'none', '2018-01-29 02:06:08', 'no', 'no', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `signup_date` date NOT NULL,
  `profile_pic` varchar(255) NOT NULL,
  `num_posts` int(11) NOT NULL,
  `num_likes` int(11) NOT NULL,
  `user_closed` varchar(3) NOT NULL,
  `friend_array` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `username`, `email`, `password`, `signup_date`, `profile_pic`, `num_posts`, `num_likes`, `user_closed`, `friend_array`) VALUES
(15, 'John', 'Lee', 'john_lee', 'Lee83@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99', '2018-01-26', 'assets/images/profile_pics/defaults/head_emerald.png', 24, 2, 'no', ','),
(16, 'Bart', 'Simpson', 'bart_simpson', 'Bart@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99', '2018-01-26', 'assets/images/profile_pics/defaults/head_deep_blue.png', 4, 0, 'no', ','),
(17, 'Lisa', 'Simpson', 'lisa_simpson', 'Lisa@hotmail.com', '5f4dcc3b5aa765d61d8327deb882cf99', '2018-01-26', 'assets/images/profile_pics/defaults/head_emerald.png', 37, 0, 'no', ','),
(18, 'Homer', 'Simpson', 'homer_simpson', 'Homer@simpson.com', '5f4dcc3b5aa765d61d8327deb882cf99', '2018-01-26', 'assets/images/profile_pics/defaults/head_emerald.png', 1, 0, 'no', ',');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
