<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Lyit</title>
		<!--CONNECT CSS-->
		<!--PUT ALL OTHER LIBRARIES OR IMPORTS HERE FOR STYLING-->

		<!--ADD FONT AMESOME-->
		<link rel="stylesheet" href="css/fontawesome-all.min.css">	
		<link rel="stylesheet" href="styles.css">

	</head>
	<body>

		<!--<h1 align="center">Student Room</h1>
<!--GIVE THEM HYPERLINKS WHEN USER CLICK ON TILE TAKE THEM TO DESIRED PAGE-->
		<!--COULD ALSO PUT AN IMAGE OR ICON BELOW OR ABOVE TEXT-->
		<div id="container">

			<div id="tl"><div class="center"><p class="topics">MEETING</p><i class="fas fa-users fa-6x" style="color:white " ></i></div></div>


			<div id="tc"><div class="center"><p class="topics">FIND YOUR WAY</p><i class="fas fa-map-marker fa-6x" style="color:white " ></i></div></div>

			<div id="tr"><div class="center"><p class="topics">ACOMODATION</p><i class="fas fa-home fa-6x" style="color:white " ></i></div></div>

			<div id="ml"><div class="center"><p class="topics">WEATHER</p><i class="fas fa-sun fa-6x" style="color:white " ></i></div></div>

			<div id="mc"><div class="center"><p class="topics">NEWS</p><i class="far fa-newspaper fa-6x" style="color:white " ></i></div></div>

			<div id="mr"><div class="center"><p class="topics">RESULTS</p><i class="" style="color:white " ></i></div></div>

			<div id="bl"><div class="center"><p class="topics">Timetable</p><i class="far fa-newspaper fa-6x" style="color:white " ></i></div></div>

			<div id="bc"><div class="center"><p class="topics">CALANDER</p><i class="far fa-calendar-times fa-6x" style="color:white " ></i></div></div>

			<!--FROM MODULES YOU CAN ACCESS THE DISCUSSION BOARD-->
			<div id="br"><div class="center"><p class="topics">MODULES</p><i class="far fa-calendar-time fa-6x" style="color:white " ></i></div></div>

			
		</div>

	</body>
</html>