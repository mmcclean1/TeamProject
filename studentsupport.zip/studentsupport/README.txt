Add extracted folder to xampp/mysql/data

Should run on localhost, check list of databases.