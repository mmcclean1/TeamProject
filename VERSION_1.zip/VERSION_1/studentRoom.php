<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Lyit</title>
		<!--CONNECT CSS-->
		<link rel="stylesheet" href="assets/css/style.css">	
		
		<?php  
		include("includes/header.php");
		?>

	</head>
	<body>
		<!--		<h1 align="center">Student Room</h1>-->

		<div id="container">
			<div id="tl"><p>1</p></div>
			<div id="tc"><p>2</p></div>
			<div id="tr"><p>3</p></div>
			<div id="ml"><p>4</p></div>
			<div id="mc"><p>5</p></div>
			<div id="mr"><p>6</p></div>
			<div id="bl"><p>7</p></div>
			<div id="bc"><p>8</p></div>
			<div id="br"><p>9</p></div>
		</div>

	</body>
</html>